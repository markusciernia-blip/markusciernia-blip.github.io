# Calvio – aktuelle Demo

Diese Demo ist die aktuelle Testversion der ehemaligen FitTrack-App mit neuem Calvio-Branding.

## Kernidee
Calvio verbindet drei Bereiche:

- **Fitness** – Aktivität, Schritte und Training
- **Tracking** – Gewicht, Trends, Kalender und Kalorienbilanz
- **Nutrition** – Kalorienaufnahme, Protein, Ballaststoffe und Alltagsernährung

## Aktueller Funktionsumfang
- installierbare Web-App / PWA
- Offline-Nutzung nach dem ersten Laden
- lokale Speicherung im Browser per IndexedDB
- Start leer oder mit 32 Demo-Datensätzen
- Tageserfassung, Kalender, Tagesdetails und Back-Taste
- Defizit/Überschuss im Kalender mit Plus/Minus und Farbcodierung
- persönliche Ziele
- 7-Tage-Gewichtstrend
- Wochenvergleich
- JSON-Backup, Import-Vorschau und CSV-Export
- Info-Buttons für Eingabefelder

## Testen
Lokal:

```bash
python3 -m http.server 8080
```

Dann öffnen:

```text
http://localhost:8080
```

Für iPhone/PWA-Installation muss die Demo über HTTPS laufen, zum Beispiel über GitHub Pages.
