# Calvio Demo

Aktuelle testbare Demo-Version der Calvio-App.

Öffne `index.html` oder starte lokal einen kleinen Webserver.
