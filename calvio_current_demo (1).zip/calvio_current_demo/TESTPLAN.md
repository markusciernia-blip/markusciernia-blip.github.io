# Calvio Demo-Testplan

1. App öffnen und Ersteinrichtung prüfen.
2. Leer starten und danach Beispieldaten ergänzen.
3. Neuen Tag speichern.
4. Vortag übernehmen.
5. Eintrag bearbeiten und löschen.
6. Info-Buttons an den Feldern öffnen.
7. Kalender öffnen und Defizit/Überschuss prüfen.
8. Kalendertag antippen und Tagesdetails prüfen.
9. Ziele ändern und Zielerreichung prüfen.
10. JSON-Backup exportieren.
11. Import-Vorschau testen.
12. CSV exportieren.
13. Offline neu öffnen.
14. iPhone: In Safari öffnen und über Teilen → Zum Home-Bildschirm installieren.
