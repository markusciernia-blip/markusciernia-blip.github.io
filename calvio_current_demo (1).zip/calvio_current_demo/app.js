(()=>{'use strict';
const DB='fittrack-local',STORE='entries',PROFILE='fittrack-v4-profile',FOCUS='fittrack-v4-focus',ONBOARD='fittrack-v4-onboarded',SEEDFLAG='fittrack-v4-seed',BACKUP='fittrack-v4-last-backup';
const defaults={name:'Jenny',goalWeight:null,protein:140,fiber:30,steps:11500,water:2.5,sleep:8,balance:-400};
let db,entries=[],period='month',editingDate=null,pending=null,deferredPrompt=null,calendarDate=new Date(),importCandidate=null;
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],n0=new Intl.NumberFormat('de-DE',{maximumFractionDigits:0}),n1=new Intl.NumberFormat('de-DE',{maximumFractionDigits:1}),ds=new Intl.DateTimeFormat('de-DE',{day:'2-digit',month:'2-digit',year:'numeric'}),dl=new Intl.DateTimeFormat('de-DE',{weekday:'long',day:'2-digit',month:'long',year:'numeric'}),monthFmt=new Intl.DateTimeFormat('de-DE',{month:'long',year:'numeric'});
const date=s=>new Date(s+'T12:00:00'),today=()=>{let d=new Date;return new Date(d-d.getTimezoneOffset()*60000).toISOString().slice(0,10)},num=v=>v===''||v==null?null:Number(v),bal=e=>Number(e.intake||0)-Number(e.tdee||0),signed=v=>(v>0?'+':v<0?'−':'')+n0.format(Math.abs(v))+' kcal',fmt=(v,u='',d=1)=>v==null||Number.isNaN(Number(v))?'–':(d?n1:n0).format(Number(v))+u,kcal=v=>v==null?'–':n0.format(v)+' kcal';
function profile(){try{return{...defaults,...JSON.parse(localStorage.getItem(PROFILE)||'{}')}}catch{return{...defaults}}}function focus(){try{return JSON.parse(localStorage.getItem(FOCUS))||['protein','fiber','steps']}catch{return['protein','fiber','steps']}}
function openDb(){return new Promise((ok,no)=>{let r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:'date'})};r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}function os(m='readonly'){return db.transaction(STORE,m).objectStore(STORE)}function all(){return new Promise((ok,no)=>{let r=os().getAll();r.onsuccess=()=>ok(r.result||[]);r.onerror=()=>no(r.error)})}function one(k){return new Promise((ok,no)=>{let r=os().get(k);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}function put(e){return new Promise((ok,no)=>{let r=os('readwrite').put(e);r.onsuccess=ok;r.onerror=()=>no(r.error)})}function del(k){return new Promise((ok,no)=>{let r=os('readwrite').delete(k);r.onsuccess=ok;r.onerror=()=>no(r.error)})}function clear(){return new Promise((ok,no)=>{let r=os('readwrite').clear();r.onsuccess=ok;r.onerror=()=>no(r.error)})}
async function seedMissing(){let dates=new Set((await all()).map(e=>e.date)),count=0;for(const e of window.FITTRACK_SEED_DATA||[])if(!dates.has(e.date)){await put({...e,source:'Tabellenimport'});count++}localStorage.setItem(SEEDFLAG,'1');return count}async function removeSeed(){let list=await all(),count=0;for(const e of list)if(e.source==='Tabellenimport'){await del(e.date);count++}return count}
async function refresh(){entries=(await all()).sort((a,b)=>a.date.localeCompare(b.date));render()}
function range(which){if(!entries.length)return[];let last=date(entries.at(-1).date);if(which==='today')return[entries.at(-1)];if(which==='week'){let s=new Date(last);s.setDate(s.getDate()-6);return entries.filter(e=>date(e.date)>=s)}if(which==='month')return entries.filter(e=>{let d=date(e.date);return d.getMonth()===last.getMonth()&&d.getFullYear()===last.getFullYear()});return entries}
function agg(list){let avg=k=>{let a=list.filter(e=>e[k]!=null);return a.length?a.reduce((s,e)=>s+Number(e[k]),0)/a.length:null},sum=k=>list.reduce((s,e)=>s+Number(e[k]||0),0);return{days:list.length,intake:avg('intake'),tdee:avg('tdee'),balance:list.reduce((s,e)=>s+bal(e),0),weight:avg('weight'),protein:avg('protein'),fiber:avg('fiber'),steps:avg('steps'),water:avg('water'),sleep:avg('sleep'),training:sum('training')}}
function rolling(list,key,days=7){return list.map((e,i)=>{let slice=list.slice(Math.max(0,i-days+1),i+1).filter(x=>x[key]!=null);return slice.length?slice.reduce((s,x)=>s+Number(x[key]),0)/slice.length:null})}
function render(){renderOverview();renderNutrition();renderProgress();renderCalendar();renderSettings();checkNotices()}
function renderOverview(){let p=profile(),list=range(period),a=agg(list),latest=entries.at(-1);$('#profileName').textContent=p.name||'Du';$('#summaryBalance').textContent=signed(a.balance);$('#summaryDays').textContent=a.days+' erfasste Tage';$('#summaryIntake').textContent=kcal(a.intake);$('#summaryTdee').textContent=kcal(a.tdee);let weights=entries.filter(e=>e.weight!=null),roll=rolling(weights,'weight');let trend=roll.at(-1);$('#summaryWeight').textContent=fmt(trend,' kg');let prev=roll.length>7?roll.at(-8):roll[0];$('#summaryWeightChange').textContent=trend!=null&&prev!=null?'7-Tage-Trend '+weightDelta(trend-prev):'Noch kein Trend';renderFocus(latest,p);drawWeight('overviewWeightChart',weights.slice(-30));$('#overviewWeightNote').textContent=weights.length>1?`Letzter Wert ${fmt(weights.at(-1).weight,' kg')} · Trend ${fmt(trend,' kg')}`:'Mindestens zwei Gewichtswerte nötig.';$('#trendBadge').textContent=trend!=null&&prev!=null?weightDelta(trend-prev):'–';if(latest){$('#latestDate').textContent=dl.format(date(latest.date));$('#latestMetrics').innerHTML=[['Aufnahme',kcal(latest.intake)],['TDEE',kcal(latest.tdee)],['Bilanz',signed(bal(latest))],['Gewicht',fmt(latest.weight,' kg')],['Protein',fmt(latest.protein,' g')],['Schritte',fmt(latest.steps,'',0)]].map(x=>`<div><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');$('#latestNote').textContent=latest.note||'Keine Notiz.';$('#editLatest').hidden=false}else{$('#latestDate').textContent='Noch keine Daten';$('#latestMetrics').innerHTML='';$('#latestNote').textContent='';$('#editLatest').hidden=true}renderWeekCompare()}
const defs={protein:{icon:'💪',title:'Protein',unit:' g',goal:p=>p.protein},fiber:{icon:'🌾',title:'Ballaststoffe',unit:' g',goal:p=>p.fiber},steps:{icon:'🚶',title:'Schritte',unit:'',goal:p=>p.steps,dec:0},weight:{icon:'⚖️',title:'Gewicht',unit:' kg',goal:p=>p.goalWeight},water:{icon:'💧',title:'Wasser',unit:' l',goal:p=>p.water},sleep:{icon:'🌙',title:'Schlaf',unit:' h',goal:p=>p.sleep}};
function renderFocus(latest,p){$('#focusCards').innerHTML=focus().slice(0,3).map(k=>{let d=defs[k],v=latest?.[k],g=d.goal(p),pct=v!=null&&g?Math.min(100,v/g*100):0,text=v==null?'Nicht erfasst':g?`${fmt(v,d.unit,d.dec??1)} von ${fmt(g,d.unit,d.dec??1)}`:fmt(v,d.unit,d.dec??1);return`<article class="focus-card"><span class="icon">${d.icon}</span><h3>${d.title}</h3><strong>${fmt(v,d.unit,d.dec??1)}</strong><p>${text}</p><div class="meter"><i style="width:${pct}%"></i></div></article>`}).join('')}
function renderWeekCompare(){let last=entries.slice(-7),prior=entries.slice(-14,-7),a=agg(last),b=agg(prior),delta=a.balance-b.balance;$('#weekCompareBadge').textContent=prior.length?`${delta>0?'+':''}${n0.format(delta)} kcal`:'Noch kein Vergleich';$('#weekCompare').innerHTML=[['Bilanz aktuell',signed(a.balance)],['Bilanz davor',prior.length?signed(b.balance):'–'],['Ø Protein',fmt(a.protein,' g')],['Ø Schritte',fmt(a.steps,'',0)],['Training',fmt(a.training,' min',0)],['Erfasste Tage',a.days]].map(x=>`<div><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')}
function renderNutrition(){let list=$('#nutritionPeriod').value==='all'?entries:entries.slice(-Number($('#nutritionPeriod').value)),q=$('#nutritionSearch').value.toLowerCase();if(q)list=list.filter(e=>(e.date+' '+(e.note||'')).toLowerCase().includes(q));let a=agg(list),p=profile();$('#nutritionProtein').textContent=fmt(a.protein,' g');$('#nutritionFiber').textContent=fmt(a.fiber,' g');$('#nutritionIntake').textContent=kcal(a.intake);$('#nutritionProteinGoal').textContent='Ziel: '+fmt(p.protein,' g',0);$('#nutritionFiberGoal').textContent='Ziel: '+fmt(p.fiber,' g',0);$('#nutritionPeriodLabel').textContent=list.length+' Einträge';$('#nutritionRows').innerHTML=[...list].reverse().map(e=>`<tr><td>${ds.format(date(e.date))}</td><td>${kcal(e.intake)}</td><td>${kcal(e.tdee)}</td><td class="${bal(e)<=0?'negative':'positive'}">${signed(bal(e))}</td><td>${fmt(e.protein,' g')}</td><td>${fmt(e.fiber,' g')}</td><td><button data-edit="${e.date}">Bearbeiten</button></td></tr>`).join('')}
function renderProgress(){let weights=entries.filter(e=>e.weight!=null);drawWeight('weightChart',weights);drawBars('balanceChart',entries);let roll=rolling(weights,'weight'),first=roll.find(v=>v!=null),last=roll.at(-1);$('#weightTrend').textContent=first!=null&&last!=null?`7-Tage-Trend: ${fmt(first,' kg')} → ${fmt(last,' kg')} (${weightDelta(last-first)})`:'Nicht genügend Gewichtsdaten.';let p=profile(),list=entries.slice(-30),hit=(k,g,cmp=(v,t)=>v>=t)=>{let valid=list.filter(e=>e[k]!=null);return valid.length?Math.round(valid.filter(e=>cmp(Number(e[k]),g)).length/valid.length*100):0};$('#goalStats').innerHTML=[['Protein',hit('protein',p.protein)+' %'],['Ballaststoffe',hit('fiber',p.fiber)+' %'],['Schritte',hit('steps',p.steps)+' %'],['Wasser',hit('water',p.water)+' %'],['Schlaf',hit('sleep',p.sleep)+' %'],['Bilanzziel',Math.round((list.filter(e=>bal(e)<=p.balance).length/(list.length||1))*100)+' %']].map(x=>`<div><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');$('#progressCount').textContent=entries.length+' Einträge';let groups=[];for(let i=0;i<entries.length;i+=7){let part=entries.slice(i,i+7);groups.push({part,a:agg(part)})}$('#weekList').innerHTML=groups.reverse().map(g=>`<div class="week-item"><b>${ds.format(date(g.part[0].date))} – ${ds.format(date(g.part.at(-1).date))}</b><span>${g.part.length} Tage</span><span>Ø ${fmt(g.a.weight,' kg')}</span><strong class="${g.a.balance<=0?'negative':'positive'}">${signed(g.a.balance)}</strong></div>`).join('')}
function renderCalendar(){let y=calendarDate.getFullYear(),m=calendarDate.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),offset=(first.getDay()+6)%7,map=new Map(entries.map(e=>[e.date,e]));$('#calendarTitle').textContent=monthFmt.format(first);let html='';for(let i=0;i<offset;i++)html+='<div class="calendar-day blank"></div>';for(let d=1;d<=days;d++){let iso=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,e=map.get(iso),filled=e?[e.intake,e.tdee,e.weight,e.protein,e.fiber,e.steps].filter(v=>v!=null).length:0,cl=filled>=5?'complete':filled?'partial':'',todayCl=iso===today()?' today':'';html+=`<button class="calendar-day ${cl}${todayCl}" data-day="${iso}"><b>${d}</b><small>${e?`${n0.format(e.intake)} kcal`:'Kein Eintrag'}</small></button>`}$('#calendarGrid').innerHTML=html}
function renderSettings(){let p=profile();$('#nameInput').value=p.name;$('#goalWeightInput').value=p.goalWeight??'';$('#goalProteinInput').value=p.protein;$('#goalFiberInput').value=p.fiber;$('#goalStepsInput').value=p.steps;$('#goalWaterInput').value=p.water;$('#goalSleepInput').value=p.sleep;$('#goalBalanceInput').value=p.balance;bindFocus($('#focusSettings'));bindFocus($('#focusDialogSettings'));let last=localStorage.getItem(BACKUP);$('#backupInfo').textContent=last?'Letztes Backup: '+new Date(last).toLocaleString('de-DE'):'Noch kein Backup erstellt.';$('#dataInfo').textContent=`Version 4 · ${entries.length} lokale Datensätze · ${entries.filter(e=>e.source==='Tabellenimport').length} historische Startdaten.`;if(navigator.storage?.estimate)navigator.storage.estimate().then(x=>$('#storageInfo').textContent=`Lokaler Speicher: ca. ${Math.round((x.usage||0)/1024)} KB verwendet.`);installInfo()}
function focusMarkup(){let sel=focus();return Object.entries(defs).map(([k,d])=>`<label class="toggle"><span>${d.icon} ${d.title}</span><input type="checkbox" data-focus="${k}" ${sel.includes(k)?'checked':''}></label>`).join('')}function bindFocus(el){el.innerHTML=focusMarkup();el.querySelectorAll('[data-focus]').forEach(x=>x.onchange=()=>{let s=focus(),k=x.dataset.focus;if(x.checked&&!s.includes(k)){if(s.length>=3){x.checked=false;alert('Bitte maximal drei Werte auswählen.');return}s.push(k)}else s=s.filter(v=>v!==k);localStorage.setItem(FOCUS,JSON.stringify(s));render()})}
function drawWeight(id,list){let c=$('#'+id),x=c.getContext('2d'),w=Math.max(280,c.clientWidth),h=270,r=devicePixelRatio||1;c.width=w*r;c.height=h*r;x.setTransform(r,0,0,r,0,0);x.clearRect(0,0,w,h);if(list.length<2)return;let vals=list.map(e=>e.weight),trend=rolling(list,'weight'),allv=[...vals,...trend.filter(v=>v!=null)],mi=Math.min(...allv)-.2,ma=Math.max(...allv)+.2,p={l:42,r:12,t:16,b:26};x.strokeStyle='#dce5f3';for(let i=0;i<5;i++){let y=p.t+(h-p.t-p.b)*i/4;x.beginPath();x.moveTo(p.l,y);x.lineTo(w-p.r,y);x.stroke()}function line(arr,color,width){x.beginPath();arr.forEach((v,i)=>{if(v==null)return;let px=p.l+(w-p.l-p.r)*i/(arr.length-1),py=p.t+(ma-v)/(ma-mi)*(h-p.t-p.b);i?x.lineTo(px,py):x.moveTo(px,py)});x.strokeStyle=color;x.lineWidth=width;x.stroke()}line(vals,'#9aafd8',1.5);line(trend,'#0b42c8',3.5)}
function drawBars(id,list){let c=$('#'+id),x=c.getContext('2d'),w=Math.max(280,c.clientWidth),h=270,r=devicePixelRatio||1;c.width=w*r;c.height=h*r;x.setTransform(r,0,0,r,0,0);x.clearRect(0,0,w,h);if(!list.length)return;let vals=list.map(bal),max=Math.max(1,...vals.map(Math.abs)),mid=h/2,gap=2,bw=Math.max(2,(w-gap*(vals.length-1))/vals.length);x.strokeStyle='#bfcadd';x.beginPath();x.moveTo(0,mid);x.lineTo(w,mid);x.stroke();vals.forEach((v,i)=>{let bh=Math.abs(v)/max*(h/2-12);x.fillStyle=v<=0?'#168a54':'#d94747';x.fillRect(i*(bw+gap),v<=0?mid-bh:mid,bw,bh)})}
function weightDelta(v){return(v>0?'+':v<0?'−':'')+n1.format(Math.abs(v))+' kg'}
function setScreen(s){$$('.screen').forEach(x=>x.classList.toggle('active',x.dataset.screen===s));$$('.bottom-nav button').forEach(x=>x.classList.toggle('active',x.dataset.target===s));scrollTo({top:0,behavior:'smooth'});if(s==='entry')prepareEntry();setTimeout(render,50)}
function prepareEntry(iso){editingDate=null;$('#entryForm').reset();$('#dateInput').value=iso||today();$('#deleteEntry').hidden=true;$('#entryStatus').textContent='';$('#validationBox').hidden=true;let existing=entries.find(e=>e.date===(iso||today()));if(existing)fill(existing);else live()}
function fill(e){editingDate=e.date;['date','weight','intake','tdee','protein','fiber','steps','water','sleep','training','trainingType','note'].forEach(k=>$('#'+k+'Input').value=e[k]??'');$('#deleteEntry').hidden=false;live()}
function readForm(){let g=k=>num($('#'+k+'Input').value);return{date:$('#dateInput').value,weight:g('weight'),intake:g('intake'),tdee:g('tdee'),protein:g('protein'),fiber:g('fiber'),steps:g('steps'),water:g('water'),sleep:g('sleep'),training:g('training'),trainingType:$('#trainingTypeInput').value.trim(),note:$('#noteInput').value.trim(),source:editingDate?(entries.find(e=>e.date===editingDate)?.source||'Lokale Eingabe'):'Lokale Eingabe',updatedAt:new Date().toISOString()}}
function validate(e){let w=[];if(!e.date)w.push('Datum fehlt.');if(e.intake==null)w.push('Kalorienaufnahme fehlt.');if(e.tdee==null)w.push('TDEE fehlt.');if(e.weight!=null&&(e.weight<30||e.weight>300))w.push('Gewicht wirkt ungewöhnlich.');if(e.intake!=null&&e.intake>7000)w.push('Kalorienaufnahme ist sehr hoch.');if(e.tdee!=null&&(e.tdee<800||e.tdee>6000))w.push('TDEE wirkt ungewöhnlich.');if(e.sleep!=null&&e.sleep>16)w.push('Schlafdauer wirkt ungewöhnlich.');return w}
function live(){let i=num($('#intakeInput').value),t=num($('#tdeeInput').value);$('#liveBalance').textContent=i==null||t==null?'–':signed(i-t)}
function ask(title,text,fn){pending=fn;$('#confirmTitle').textContent=title;$('#confirmText').textContent=text;$('#confirmDialog').showModal()}
function download(name,text,type){let u=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=u;a.download=name;a.click();URL.revokeObjectURL(u)}function exportJson(){download('fittrack-backup-'+today()+'.json',JSON.stringify({app:'Calvio',version:4,createdAt:new Date().toISOString(),profile:profile(),focus:focus(),entries},null,2),'application/json');localStorage.setItem(BACKUP,new Date().toISOString());renderSettings()}function exportCsv(){let c=['date','tdee','intake','balance','weight','protein','fiber','steps','water','sleep','training','trainingType','note'],esc=v=>'"'+String(v??'').replaceAll('"','""')+'"';download('fittrack-daten-'+today()+'.csv','\ufeff'+[c.join(';'),...entries.map(e=>c.map(k=>esc(k==='balance'?bal(e):e[k])).join(';'))].join('\n'),'text/csv')}
async function previewImport(){let f=$('#importFile').files[0];if(!f)return showImport('Bitte zuerst eine JSON-Datei auswählen.','error');try{let p=JSON.parse(await f.text()),list=Array.isArray(p)?p:p.entries;if(!Array.isArray(list))throw Error('Keine Datensätze gefunden');let valid=list.filter(e=>e.date&&Number.isFinite(Number(e.intake))&&Number.isFinite(Number(e.tdee))),existing=new Set(entries.map(e=>e.date)),dupes=valid.filter(e=>existing.has(String(e.date).slice(0,10))).length;importCandidate={payload:p,list:valid};showImport(`${valid.length} gültige Einträge gefunden.\n${dupes} Datumsüberschneidungen werden aktualisiert.\n${list.length-valid.length} ungültige Einträge werden übersprungen.`,'ok');$('#importJson').hidden=false}catch(e){importCandidate=null;$('#importJson').hidden=true;showImport('Import nicht möglich: '+e.message,'error')}}function showImport(t,cl){let b=$('#importPreview');b.textContent=t;b.className='validation '+cl;b.hidden=false}async function doImport(){if(!importCandidate)return;for(let e of importCandidate.list)await put({...e,date:String(e.date).slice(0,10),intake:Number(e.intake),tdee:Number(e.tdee)});let p=importCandidate.payload;if(p.profile)localStorage.setItem(PROFILE,JSON.stringify({...defaults,...p.profile}));if(Array.isArray(p.focus))localStorage.setItem(FOCUS,JSON.stringify(p.focus.slice(0,3)));await refresh();$('#importStatus').textContent=importCandidate.list.length+' Einträge importiert.';importCandidate=null;$('#importJson').hidden=true}
function checkNotices(){let n=$('#noticeBar'),latest=entries.at(-1),lastBackup=localStorage.getItem(BACKUP),messages=[];if(!entries.some(e=>e.date===today()))messages.push('Für heute fehlt noch ein Eintrag.');if(!lastBackup||Date.now()-new Date(lastBackup)>30*864e5)messages.push('Backup empfohlen.');if(latest&&Date.now()-date(latest.date)>7*864e5)messages.push('Seit über 7 Tagen keine neuen Daten.');n.textContent=messages.join(' · ');n.hidden=!messages.length}
function runCheck(){let duplicates=entries.length-new Set(entries.map(e=>e.date)).size,invalid=entries.filter(e=>!e.date||e.intake==null||e.tdee==null).length,odd=entries.filter(e=>(e.weight!=null&&(e.weight<30||e.weight>300))||e.intake>7000||e.tdee>6000).length,b=$('#checkResult');b.textContent=`${entries.length} Datensätze geprüft.\nDoppelte Tage: ${duplicates}\nUnvollständig: ${invalid}\nAuffällig: ${odd}`;b.className='validation '+(duplicates||invalid?'error':'ok');b.hidden=false}
function installInfo(){let standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone===true,ios=/iphone|ipad|ipod/i.test(navigator.userAgent);if(standalone){$('#installGuide').textContent='Calvio ist bereits als App installiert.';$('#installAppAction').hidden=true}else if(deferredPrompt){$('#installGuide').textContent='Calvio kann wie eine normale App installiert werden.';$('#installAppAction').hidden=false}else{$('#installGuide').textContent=ios?'In Safari: Teilen → Zum Home-Bildschirm.':'Browser-Menü → App installieren oder Zum Startbildschirm hinzufügen.';$('#installAppAction').hidden=false}}async function requestInstall(){if(deferredPrompt){deferredPrompt.prompt();let r=await deferredPrompt.userChoice;$('#installStatus').textContent=r.outcome==='accepted'?'Installation gestartet.':'Installation abgebrochen.';deferredPrompt=null;installInfo()}else alert(/iphone|ipad|ipod/i.test(navigator.userAgent)?'Safari: Teilen antippen und „Zum Home-Bildschirm“ wählen.':'Browser-Menü öffnen und „App installieren“ auswählen.')}
function bind(){$$('.bottom-nav button').forEach(b=>b.onclick=()=>setScreen(b.dataset.target));$$('.open-entry').forEach(b=>b.onclick=()=>setScreen('entry'));$('#periodSwitch').onclick=e=>{let b=e.target.closest('[data-period]');if(!b)return;period=b.dataset.period;$('#periodSwitch').querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));renderOverview()};$('#editLatest').onclick=()=>{setScreen('entry');prepareEntry(entries.at(-1).date)};$('#editFocus').onclick=()=>$('#focusDialog').showModal();$$('[data-close]').forEach(b=>b.onclick=()=>$('#'+b.dataset.close).close());$('#nutritionPeriod').onchange=renderNutrition;$('#nutritionSearch').oninput=renderNutrition;document.body.onclick=e=>{let b=e.target.closest('[data-edit]');if(b){setScreen('entry');prepareEntry(b.dataset.edit)}let d=e.target.closest('[data-day]');if(d){setScreen('entry');prepareEntry(d.dataset.day)}};$('#prevMonth').onclick=()=>{calendarDate.setMonth(calendarDate.getMonth()-1);renderCalendar()};$('#nextMonth').onclick=()=>{calendarDate.setMonth(calendarDate.getMonth()+1);renderCalendar()};$('#intakeInput').oninput=$('#tdeeInput').oninput=live;$('#entryForm').onreset=()=>setTimeout(()=>prepareEntry(),0);$('#copyPrevious').onclick=()=>{let d=$('#dateInput').value,prior=[...entries].reverse().find(e=>e.date<d);if(!prior)return alert('Kein früherer Eintrag vorhanden.');['weight','tdee','protein','fiber','steps','water','sleep','trainingType'].forEach(k=>$('#'+k+'Input').value=prior[k]??'');live()};$('#entryForm').onsubmit=async e=>{e.preventDefault();let v=readForm(),warnings=validate(v);if(warnings.some(x=>x.includes('fehlt'))){let b=$('#validationBox');b.textContent=warnings.join('\n');b.className='validation error';b.hidden=false;return}if(warnings.length&&!confirm(warnings.join('\n')+'\n\nTrotzdem speichern?'))return;await put(v);editingDate=v.date;await refresh();$('#entryStatus').textContent='Gespeichert.';$('#deleteEntry').hidden=false};$('#deleteEntry').onclick=()=>editingDate&&ask('Eintrag löschen?',ds.format(date(editingDate)),async()=>{await del(editingDate);editingDate=null;await refresh();prepareEntry()});$('#confirmDialog').onclose=async()=>{if($('#confirmDialog').returnValue==='confirm'&&pending)await pending();pending=null};$('#saveProfile').onclick=()=>{let p={name:$('#nameInput').value.trim()||'Du',goalWeight:num($('#goalWeightInput').value),protein:num($('#goalProteinInput').value)||140,fiber:num($('#goalFiberInput').value)||30,steps:num($('#goalStepsInput').value)||11500,water:num($('#goalWaterInput').value)||2.5,sleep:num($('#goalSleepInput').value)||8,balance:num($('#goalBalanceInput').value)??-400};localStorage.setItem(PROFILE,JSON.stringify(p));$('#profileStatus').textContent='Ziele gespeichert.';render()};$('#exportJson').onclick=exportJson;$('#exportCsv').onclick=exportCsv;$('#previewImport').onclick=previewImport;$('#importJson').onclick=doImport;$('#addDemoData').onclick=async()=>{let n=await seedMissing();await refresh();alert(n+' fehlende Startdaten ergänzt.')};$('#removeDemoData').onclick=()=>ask('Historische Startdaten entfernen?','Eigene lokale Einträge bleiben erhalten.',async()=>{let n=await removeSeed();await refresh();alert(n+' Startdaten entfernt.')});$('#clearData').onclick=()=>ask('Alle lokalen Daten löschen?','Dieser Schritt kann nur mit einem Backup rückgängig gemacht werden.',async()=>{await clear();await refresh()});$('#runCheck').onclick=runCheck;window.addEventListener('online',status);window.addEventListener('offline',status);window.addEventListener('resize',()=>{let s=$('.screen.active')?.dataset.screen;if(s==='overview'||s==='progress')render()});window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;$('#installButton').hidden=false;installInfo()});$('#installButton').onclick=$('#installAppAction').onclick=requestInstall;window.addEventListener('appinstalled',()=>{deferredPrompt=null;$('#installButton').hidden=true;installInfo()});$('#finishOnboarding').onclick=async e=>{e.preventDefault();let mode=$('input[name="startMode"]:checked').value,name=$('#onboardName').value.trim()||'Du';localStorage.setItem(PROFILE,JSON.stringify({...defaults,name}));if(mode==='demo')await seedMissing();else localStorage.setItem(SEEDFLAG,'1');localStorage.setItem(ONBOARD,'1');$('#onboardingDialog').close();await refresh()}}
function status(){let on=navigator.onLine;$('#connectionStatus').textContent=on?'Online · offline bereit':'Offline';$('#connectionStatus').classList.toggle('offline',!on)}
async function init(){bind();db=await openDb();if(localStorage.getItem(ONBOARD)){if(!localStorage.getItem(SEEDFLAG))await seedMissing()}else $('#onboardingDialog').showModal();await refresh();status();if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js?v=7',{scope:'./'}).catch(console.error);prepareEntry()}
init().catch(e=>{console.error(e);alert('Calvio konnte nicht gestartet werden. Bitte Browser-Speicher prüfen.')});
})();


// --- Calvio Demo v2 usability enhancements: back button, field info, day detail, clear calendar balance ---
(function(){
  const FIELD_HELP = {
    dateInput: 'Der Tag, für den du Daten speichern möchtest. Pro Datum gibt es einen Eintrag.',
    weightInput: 'Dein Körpergewicht in kg. Für Trends ist der 7-Tage-Durchschnitt wichtiger als ein einzelner Tageswert.',
    intakeInput: 'Alle aufgenommenen Kalorien des Tages. Daraus wird zusammen mit dem TDEE die Tagesbilanz berechnet.',
    tdeeInput: 'TDEE ist dein geschätzter Gesamtenergieverbrauch des Tages. Aufnahme minus TDEE ergibt Defizit oder Überschuss.',
    proteinInput: 'Proteinmenge in Gramm. Hilft beim Erhalt und Aufbau von Muskelmasse.',
    fiberInput: 'Ballaststoffe in Gramm. Gut für Sättigung, Verdauung und Blutzuckerstabilität.',
    stepsInput: 'Alle Schritte des Tages. Ein einfacher Marker für Alltagsaktivität.',
    waterInput: 'Getrunkene Wassermenge in Litern. Optionaler Wert für deine Tagesroutine.',
    sleepInput: 'Schlafdauer in Stunden. Optional, aber hilfreich zur Einordnung von Gewicht, Hunger und Leistung.',
    trainingInput: 'Trainingsdauer in Minuten. Zum Beispiel Krafttraining, Ausdauer oder Spaziergang.',
    trainingTypeInput: 'Art des Trainings, zum Beispiel Krafttraining, Laufen, Radfahren oder Spaziergang.',
    noteInput: 'Freitext für Besonderheiten: Hunger, Stress, Zyklus, Krankheit, Restaurant, Stimmung oder Training.'
  };

  function safe$(sel){ return document.querySelector(sel); }
  function safeAll(sel){ return Array.from(document.querySelectorAll(sel)); }
  function fmtNum(v, dec=0){
    if(v == null || Number.isNaN(Number(v))) return '–';
    return new Intl.NumberFormat('de-DE', {maximumFractionDigits: dec}).format(Number(v));
  }
  function fmtDate(iso){
    try { return new Intl.DateTimeFormat('de-DE',{weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(new Date(iso+'T12:00:00')); }
    catch { return iso; }
  }
  function balanceOf(e){ return Number(e?.intake || 0) - Number(e?.tdee || 0); }
  function signedKcal(v){
    const sign = v > 0 ? '+' : v < 0 ? '−' : '';
    return sign + fmtNum(Math.abs(v),0) + ' kcal';
  }
  function getEntries(){
    try { return Array.isArray(window.entries) ? window.entries : []; } catch { return []; }
  }
  function getDbEntriesFromDomFallback(){ return getEntries(); }

  function addBackButtons(){
    safeAll('[data-back]').forEach(btn => {
      btn.onclick = () => {
        const active = safe$('.screen.active')?.dataset?.screen;
        if(active && active !== 'overview') {
          const overviewBtn = safe$('.bottom-nav [data-target="overview"]');
          overviewBtn?.click();
        } else {
          history.back();
        }
      };
    });
  }

  function addFieldHelp(){
    for(const [id, text] of Object.entries(FIELD_HELP)){
      const input = safe$('#'+id);
      if(!input) continue;
      const label = input.closest('label');
      if(!label || label.querySelector('.info-btn')) continue;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'info-btn';
      btn.setAttribute('aria-label','Info zu diesem Feld');
      btn.textContent = 'i';
      const help = document.createElement('div');
      help.className = 'field-help';
      help.textContent = text;
      btn.onclick = (ev) => {
        ev.preventDefault();
        help.classList.toggle('active');
      };
      label.insertBefore(btn, input);
      label.appendChild(help);
    }
  }

  function buildDayDetail(entry){
    if(!entry) return '<div class="detail-card">Für diesen Tag ist noch kein Eintrag gespeichert.</div>';
    const b = balanceOf(entry);
    const kind = b < 0 ? 'Defizit' : b > 0 ? 'Überschuss' : 'Ausgeglichen';
    return `
      <div class="detail-card">
        <span>Kalorienbilanz</span>
        <b class="${b <= 0 ? 'negative' : 'positive'}">${kind}: ${signedKcal(b)}</b>
      </div>
      <div class="detail-grid">
        <div><span>Kalorienaufnahme</span><b>${fmtNum(entry.intake)} kcal</b></div>
        <div><span>TDEE</span><b>${fmtNum(entry.tdee)} kcal</b></div>
        <div><span>Gewicht</span><b>${entry.weight == null ? '–' : fmtNum(entry.weight,1) + ' kg'}</b></div>
        <div><span>Protein</span><b>${entry.protein == null ? '–' : fmtNum(entry.protein,1) + ' g'}</b></div>
        <div><span>Ballaststoffe</span><b>${entry.fiber == null ? '–' : fmtNum(entry.fiber,1) + ' g'}</b></div>
        <div><span>Schritte</span><b>${entry.steps == null ? '–' : fmtNum(entry.steps)}</b></div>
        <div><span>Wasser</span><b>${entry.water == null ? '–' : fmtNum(entry.water,1) + ' l'}</b></div>
        <div><span>Schlaf</span><b>${entry.sleep == null ? '–' : fmtNum(entry.sleep,1) + ' h'}</b></div>
        <div><span>Training</span><b>${entry.training == null ? '–' : fmtNum(entry.training) + ' min'}</b></div>
        <div><span>Trainingsart</span><b>${entry.trainingType || '–'}</b></div>
      </div>
      <div class="detail-card"><span>Notiz</span><b>${entry.note || 'Keine Notiz'}</b></div>
    `;
  }

  window.openCalvioDayDetail = function(iso){
    const entry = getEntries().find(e => e.date === iso);
    const title = safe$('#dayDetailTitle');
    const body = safe$('#dayDetailBody');
    const edit = safe$('#dayDetailEdit');
    if(title) title.textContent = fmtDate(iso);
    if(body) body.innerHTML = buildDayDetail(entry);
    if(edit){
      edit.hidden = false;
      edit.onclick = () => {
        safe$('#dayDetailDialog')?.close();
        if(typeof window.openEntry === 'function') window.openEntry(iso);
        else safe$('.bottom-nav [data-target="entry"]')?.click();
      };
    }
    safe$('#dayDetailDialog')?.showModal();
  };

  function enhanceCalendarCells(){
    const entries = getEntries();
    const byDate = new Map(entries.map(e => [e.date, e]));
    safeAll('.calendar-day').forEach(cell => {
      if(cell.classList.contains('blank')) return;
      const iso = cell.dataset.date || cell.getAttribute('data-date');
      if(!iso) return;
      const entry = byDate.get(iso);
      cell.onclick = () => window.openCalvioDayDetail(iso);
      cell.title = 'Tagesdetails öffnen';
      let old = cell.querySelector('.balance');
      if(old) old.remove();
      let oldNote = cell.querySelector('.cal-note');
      if(oldNote) oldNote.remove();
      if(entry){
        const b = balanceOf(entry);
        cell.classList.remove('deficit','surplus','neutral');
        cell.classList.add(b < 0 ? 'deficit' : b > 0 ? 'surplus' : 'neutral');
        const strong = document.createElement('strong');
        strong.className = 'balance ' + (b <= 0 ? 'negative' : 'positive');
        strong.textContent = (b < 0 ? 'Defizit ' : b > 0 ? 'Überschuss ' : '± ') + signedKcal(b).replace('−','-');
        const note = document.createElement('div');
        note.className = 'cal-note';
        note.textContent = 'Aufnahme − TDEE';
        cell.appendChild(strong);
        cell.appendChild(note);
      }
    });
    const legend = safe$('.calendar-legend');
    if(legend && !legend.querySelector('.legend-balance')){
      const p = document.createElement('p');
      p.className = 'legend-balance';
      p.textContent = 'Die Zahl im Kalendertag zeigt die Kalorienbilanz: Aufnahme minus TDEE. Negativ = Defizit, positiv = Überschuss.';
      legend.appendChild(p);
    }
  }

  function observeCalendar(){
    const grid = safe$('#calendarGrid');
    if(!grid) return;
    const obs = new MutationObserver(() => enhanceCalendarCells());
    obs.observe(grid, {childList:true, subtree:true});
    setTimeout(enhanceCalendarCells, 300);
  }

  function exposeOpenEntry(){
    // In some builds openEntry is scoped. Calendar details still show data; edit falls back to entry screen.
    if(!window.openEntry){
      window.openEntry = function(iso){
        safe$('.bottom-nav [data-target="entry"]')?.click();
        const dateInput = safe$('#dateInput');
        if(dateInput && iso) dateInput.value = iso;
      };
    }
  }

  function initEnhancements(){
    addBackButtons();
    addFieldHelp();
    exposeOpenEntry();
    observeCalendar();
    safeAll('[data-close]').forEach(btn => btn.addEventListener('click', () => safe$('#'+btn.dataset.close)?.close()));
    setInterval(enhanceCalendarCells, 1500);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initEnhancements);
  else initEnhancements();
})();


// --- Calvio Demo v3: persistent Back button and clearer calendar deficit/surplus badges ---
(function(){
  function q(s){ return document.querySelector(s); }
  function qa(s){ return Array.from(document.querySelectorAll(s)); }
  function currentScreen(){ return q('.screen.active')?.dataset?.screen || 'overview'; }
  function setScreenByName(name){
    const btn = q('.bottom-nav [data-target="'+name+'"]');
    if(btn) btn.click();
    else {
      qa('.screen').forEach(s => s.classList.toggle('active', s.dataset.screen === name));
      qa('.bottom-nav button').forEach(b => b.classList.toggle('active', b.dataset.target === name));
    }
  }
  function updateBackButton(){
    const back = q('#globalBackButton');
    if(!back) return;
    const screen = currentScreen();
    back.hidden = screen === 'overview';
    back.onclick = () => {
      if(currentScreen() !== 'overview') setScreenByName('overview');
      else history.back();
    };
  }
  function parseGermanNumber(text){
    if(!text) return null;
    const m = String(text).match(/[+\-−]?\s*[\d.]+(?:,\d+)?/);
    if(!m) return null;
    return Number(m[0].replace('−','-').replace(/\./g,'').replace(',','.').replace(/\s/g,''));
  }
  function entryFromKnownGlobals(iso){
    try {
      if(Array.isArray(window.entries)) return window.entries.find(e => e.date === iso);
    } catch {}
    return null;
  }
  function computeBalanceFromCell(cell, iso){
    const entry = entryFromKnownGlobals(iso);
    if(entry) return Number(entry.intake || 0) - Number(entry.tdee || 0);

    // fallback: check any existing text in the day cell
    const existing = cell.textContent || '';
    const value = parseGermanNumber(existing);
    // Avoid using the day number itself as balance: balances usually have kcal or +/- near them.
    if(/[kK]cal|Defizit|Überschuss|[+\-−]\s*\d/.test(existing) && Math.abs(value || 0) > 31) return value;
    return null;
  }
  function formatSigned(v){
    if(v == null || Number.isNaN(v)) return '';
    const abs = Math.round(Math.abs(v)).toLocaleString('de-DE');
    if(v < 0) return '−' + abs + ' kcal';
    if(v > 0) return '+' + abs + ' kcal';
    return '±0 kcal';
  }
  function labelFor(v){
    if(v == null || Number.isNaN(v)) return '';
    if(v < 0) return 'Defizit';
    if(v > 0) return 'Überschuss';
    return 'neutral';
  }
  function isoFromCell(cell){
    return cell.dataset.date || cell.getAttribute('data-date') || cell.getAttribute('data-day') || '';
  }
  function cleanOldCalendarMarkup(cell){
    cell.querySelectorAll('.balance,.cal-note,.calendar-balance-badge,.calendar-balance-label').forEach(n => n.remove());
  }
  function enhanceCalendar(){
    qa('.calendar-day').forEach(cell => {
      if(cell.classList.contains('blank')) return;
      const iso = isoFromCell(cell);
      cleanOldCalendarMarkup(cell);
      cell.classList.remove('deficit','surplus','neutral');

      const balance = computeBalanceFromCell(cell, iso);
      if(balance != null && !Number.isNaN(balance)){
        const kind = balance < 0 ? 'deficit' : balance > 0 ? 'surplus' : 'neutral';
        cell.classList.add(kind);

        const badge = document.createElement('strong');
        badge.className = 'calendar-balance-badge';
        badge.textContent = formatSigned(balance);

        const label = document.createElement('span');
        label.className = 'calendar-balance-label';
        label.textContent = labelFor(balance);

        cell.appendChild(badge);
        cell.appendChild(label);
      }

      if(iso){
        cell.onclick = () => {
          if(typeof window.openCalvioDayDetail === 'function') window.openCalvioDayDetail(iso);
          else {
            setScreenByName('entry');
            const input = q('#dateInput');
            if(input) input.value = iso;
          }
        };
      }
    });

    const info = q('#calendarBalanceInfo');
    if(info) info.innerHTML = '<b>Kalenderzahl:</b> <span class="deficit-text">− Defizit</span> = Aufnahme unter TDEE, <span class="surplus-text">+ Überschuss</span> = Aufnahme über TDEE.';
  }
  function observe(){
    const main = q('main') || document.body;
    const obs = new MutationObserver(() => {
      updateBackButton();
      enhanceCalendar();
    });
    obs.observe(main, {childList:true, subtree:true, attributes:true, attributeFilter:['class']});
  }
  function init(){
    updateBackButton();
    enhanceCalendar();
    observe();
    qa('.bottom-nav button').forEach(b => b.addEventListener('click', () => setTimeout(updateBackButton, 50)));
    setInterval(() => { updateBackButton(); enhanceCalendar(); }, 1200);
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
