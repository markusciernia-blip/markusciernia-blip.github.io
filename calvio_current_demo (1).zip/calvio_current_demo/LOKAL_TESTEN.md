# Lokal testen

```bash
cd calvio_current_demo
python3 -m http.server 8080
```

Dann `http://localhost:8080` öffnen.
